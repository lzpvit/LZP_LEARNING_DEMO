CREATE procedure cur_test2 is
cursor cur2 is
select student_id,student_name from student;
c_row cur2%rowtype;
begin
  open cur2;
    loop
      fetch cur2 into c_row;
      exit when cur2%notfound;
      dbms_output.put_line(c_row.student_id||'--'||c_row.student_name);
    end loop;
  close cur2;
end cur_test2;
/
