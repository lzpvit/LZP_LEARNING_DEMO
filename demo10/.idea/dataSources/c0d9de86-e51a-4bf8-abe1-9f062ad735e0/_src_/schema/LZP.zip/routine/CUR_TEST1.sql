CREATE procedure cur_test1 is
cursor cur1 is
select student_id,student_name from student;
c_row cur1%rowtype;
begin
  for c_row in cur1 loop
    dbms_output.put_line(c_row.student_id||'-'||c_row.student_name);
  end loop;
end cur_test1;
/
