CREATE procedure cur_test3 is
begin
  update student set teacher_teacher_id=3 where student_name='xiaolangmao';
  if sql%isopen then
    dbms_output.put('opening....');
    else
      dbms_output.put_line('closing....');
      end if;
  if sql%found then 
    dbms_output.put_line('游标指向有效行');
    else
      dbms_output.put_line('sorry...');
      end if;
  dbms_output.put_line(sql%rowcount);
  exception 
    when no_data_found then
      dbms_output.put_line('no data found...');
    when too_many_rows then
      dbms_output.put_line('too many rows');
end cur_test3;
/
