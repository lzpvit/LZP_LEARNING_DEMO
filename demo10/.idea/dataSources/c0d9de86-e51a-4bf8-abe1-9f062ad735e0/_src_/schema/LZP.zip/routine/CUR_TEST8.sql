CREATE procedure cur_test8(teachername in varchar,my_cursor out sys_refcursor) is
begin
  open my_cursor for select teacher_id,teacher_name from teacher where teacher_name=teachername;
end cur_test8;
/
