CREATE procedure GREETING_OUT1(niu in varchar2, zhi in varchar2, peng out varchar2) is
begin
  peng:=niu||zhi;
end GREETING_OUT1;
/
