CREATE procedure cur_test7(teachername in varchar) is
my_cursor sys_refcursor;
begin
  open my_cursor for select teacher_id,teacher_name from teacher where teacher_name=teachername;
end cur_test7;
/
