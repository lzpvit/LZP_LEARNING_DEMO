CREATE procedure cur_test5(student_nam in varchar,my_cursor out sys_refcursor) is
begin
  open my_cursor for select student_id,student_name,teacher_teacher_id from student where student_name=student_nam;
  dbms_output.put_line('my_cursor...');
end cur_test5;
/
