CREATE procedure select_student_by_teacherid(teacherid in number ,student_name out VARCHAR) is
begin
  select student_name　into student_name from student where teacher_teacher_id=teacherid;
end select_student_by_teacherid;
/
