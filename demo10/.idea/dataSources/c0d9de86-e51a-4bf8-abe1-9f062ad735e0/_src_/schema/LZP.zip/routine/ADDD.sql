CREATE FUNCTION addD
RETURN number IS
TOSL number(5):=0;
A number(5):=519;
B number(5) :=1;
BEGIN
  TOSL :=A+B;
  dbms_output.put_line('add.....ok');
  RETURN TOSL;
END addD;
/
