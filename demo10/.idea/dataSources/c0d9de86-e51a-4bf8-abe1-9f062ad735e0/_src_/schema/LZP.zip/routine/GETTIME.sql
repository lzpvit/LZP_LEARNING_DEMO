CREATE function GETTIME return varchar2 is
  FunctionResult varchar2(20);
begin
  FunctionResult:=TO_CHAR(SYSDATE,'DAY');
  DBMS_OUTPUT.put_line(FunctionResult);
  return(FunctionResult);
end GETTIME;
/
