CREATE FUNCTION bigger(a number, b number)
return number is
a1 number;
b1 number;
begin
  a1:=a;
  b1:=b;
  if(a1>=b1)then
    dbms_output.put_line(a1);
      return a1;
  else
    dbms_output.put_line(b1);
    return b1;
  end if;
end;
/
