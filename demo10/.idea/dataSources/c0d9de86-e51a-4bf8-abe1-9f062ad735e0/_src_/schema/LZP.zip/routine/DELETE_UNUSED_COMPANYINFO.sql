CREATE procedure delete_unused_companyinfo is
begin
  DELETE from COMPANYINFO WHERE (id) IN ( SELECT id FROM COMPANYINFO GROUP BY id HAVING COUNT(id) > 1) AND ROWID NOT IN (SELECT MIN(ROWID) FROM COMPANYINFO GROUP BY id HAVING COUNT(*) > 1);
  COMMIT;
end delete_unused_companyinfo;
/
