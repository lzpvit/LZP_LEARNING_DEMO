CREATE procedure CUR_TEST6(studentl in varchar,studentt out varchar) is
begin
  select student_name into studentt from student where student_name=studentl;
  dbms_output.put_line(studentt);
end CUR_TEST6;
/
