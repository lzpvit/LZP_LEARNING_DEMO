CREATE procedure INSERT_COMPANYINFO(ID  number, nam  char,code  char,address  char,locationx  char,locationy  char,province  char) is
begin
  insert into companyinfo(ID,nam,code,addresss,locationx,locationy,province)VALUES(ID,nam,code,address,locationx,locationy,province);
  commit;
end INSERT_COMPANYINFO;
/
