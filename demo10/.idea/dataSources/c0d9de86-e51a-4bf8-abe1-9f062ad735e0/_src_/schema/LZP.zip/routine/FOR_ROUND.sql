CREATE function for_round return number is
  FunctionResult number;
  add_sum number:=1;
begin
  for v_counter in 1..10 loop
    add_sum:= add_sum * v_counter;
    end loop;
   dbms_output.put_line(add_sum);
  FunctionResult:=0;
  return(FunctionResult);
end for_round;
/
