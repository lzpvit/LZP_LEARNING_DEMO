CREATE FUNCTION total
RETURN number IS
   totl number(2) := 0;
BEGIN
   totl :=12;
   dbms_output.put_line('lzp1');
   RETURN totl;
END total;
/
