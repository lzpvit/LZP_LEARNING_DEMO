CREATE function fibo(x in number) return number is
begin
  if (x=0)then
    return 0;
  elsif (x=1)then
   return 1;
  else
    return fibo(x-1)+fibo(x-2);
   end if;
end fibo;
/
