CREATE procedure GREETING_OUT(inu in varchar2,c out varchar2) is
begin
  c:='hello lzp........ '||inu;
  dbms_output.put('try.......');
end GREETING_OUT;
/
