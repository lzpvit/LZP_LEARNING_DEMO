CREATE procedure delete_id_lag is
begin
delete  from COMPANYINFO t  where id>1290;
commit;
end delete_id_lag;
/
