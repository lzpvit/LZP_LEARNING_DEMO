CREATE package mypackage As 
procedure cur_test8(teachername In varchar,my_cursor out sys_refcursor);   
End;
/
