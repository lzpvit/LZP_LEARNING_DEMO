CREATE VIEW LZP2 AS select "NUM","NAME"
    from lzp1
/
