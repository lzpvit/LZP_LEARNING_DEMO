CREATE VIEW VIEW1 AS select "ID","NAM","CODE","ADDRESSS","LOCATIONX","LOCATIONY","PROVINCE"
    from companyinfo where ADDRESSS!='none'
/
