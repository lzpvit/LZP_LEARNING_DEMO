CREATE TRIGGER LZP1
BEFORE INSERT OR UPDATE OR DELETE
  ON LZP1
FOR EACH ROW
  declare
  -- local variables here
begin
  dbms_output.put_line('first_trigger');
end LZP1;
/
